Accept user input and change the background picture to match.

For example, if your user inputs "NYC," they should see a the picture of NYC.

Do one of these for each city in the images folder.

BONUS - create a dropdown menu with the name of each city.  When the user clicks a given city, change the background to match.